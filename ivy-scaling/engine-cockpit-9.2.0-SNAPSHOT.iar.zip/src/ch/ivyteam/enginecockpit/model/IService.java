package ch.ivyteam.enginecockpit.model;

public interface IService
{
  boolean passwordChanged();
  String getPassword();
}
